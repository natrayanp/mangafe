export interface PaymentPackage {
  packageId: number;
  packageName: string;
  packageDescription: string;
  packagePrice: number;
  packageImageURL: string;
}
