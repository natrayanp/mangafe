export * from './dialogs.module';
export * from './confirm-dialog/confirm-dialog.component';
export * from './display-dialog/display-dialog.component';
export * from './ok-dialog/ok-dialog.component';