from flask import Blueprint

bp_appfunc = Blueprint('appfunc', __name__)    # APP function routes

