from flask import Blueprint

bp_entity = Blueprint('entity', __name__)  # Entity ie..company creation
bp_entitybranch = Blueprint('entitybranch', __name__)  # branch ie.. branch for a company creation