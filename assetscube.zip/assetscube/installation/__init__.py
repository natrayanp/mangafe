from flask import Blueprint

bp_install = Blueprint('install', __name__)