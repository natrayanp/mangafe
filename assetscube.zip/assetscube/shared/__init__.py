from flask import Blueprint

bp_shared = Blueprint('shared', __name__)