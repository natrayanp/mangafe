from flask import Blueprint

bp_flow = Blueprint('flow', __name__)