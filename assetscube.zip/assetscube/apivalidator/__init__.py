from flask import Blueprint

bp_apivali = Blueprint('apivalidator', __name__)    # oauth login routes
