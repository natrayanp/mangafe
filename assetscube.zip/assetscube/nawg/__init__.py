from flask import Blueprint

bp_nawg = Blueprint('nawg', __name__)